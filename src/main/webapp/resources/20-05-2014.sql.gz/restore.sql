--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.assessment_system DROP CONSTRAINT fkf2f47a4cfd0ba1a;
ALTER TABLE ONLY public.assessment_system DROP CONSTRAINT fkf2f47a4c3f21b2ce;
ALTER TABLE ONLY public.csn_category DROP CONSTRAINT fkdc65ca1ffd0ba1a;
ALTER TABLE ONLY public.csn_category DROP CONSTRAINT fkdc65ca1ff689395b;
ALTER TABLE ONLY public.csn_category DROP CONSTRAINT fkdc65ca1f3f21b2ce;
ALTER TABLE ONLY public.article DROP CONSTRAINT fkd458ccf6fd0ba1a;
ALTER TABLE ONLY public.article DROP CONSTRAINT fkd458ccf63f21b2ce;
ALTER TABLE ONLY public.address DROP CONSTRAINT fkbb979bf4fd0ba1a;
ALTER TABLE ONLY public.address DROP CONSTRAINT fkbb979bf43f21b2ce;
ALTER TABLE ONLY public.portal_order DROP CONSTRAINT fk_tl09nadh1dd4q0qn014e7yo16;
ALTER TABLE ONLY public.mandate DROP CONSTRAINT fk_sb5ifbeusyqn97v3e11m8fcvw;
ALTER TABLE ONLY public.standard_has_assessment_system DROP CONSTRAINT fk_rk252bmpbvclb0lmvfk07ne38;
ALTER TABLE ONLY public.standard_has_assessment_system DROP CONSTRAINT fk_rh7af47sextrnjycqdwhrc5bf;
ALTER TABLE ONLY public.webpage DROP CONSTRAINT fk_rd9bbp76ioumgfkaeq6c0anyd;
ALTER TABLE ONLY public.mandate DROP CONSTRAINT fk_r2rrkux4qw05h1hdv6aweh5r3;
ALTER TABLE ONLY public.standard_csn DROP CONSTRAINT fk_qk3igydwnanmd1b0nxfr6l9tv;
ALTER TABLE ONLY public.webpage DROP CONSTRAINT fk_q7io6vgavcyoodhv5dxyne1mu;
ALTER TABLE ONLY public.portal_order_has_items DROP CONSTRAINT fk_pylea48c2myf1l9sln72m7k70;
ALTER TABLE ONLY public.requirement DROP CONSTRAINT fk_ph5bf3u42jpk7ygfxp3rp7fdc;
ALTER TABLE ONLY public.standard_has_csn DROP CONSTRAINT fk_pa9lhieqojw7axvckoyjfuarv;
ALTER TABLE ONLY public.standard_is_in_standard_group DROP CONSTRAINT fk_p2yix7iis19l0uyg00uut01xm;
ALTER TABLE ONLY public.exception_log DROP CONSTRAINT fk_oqmweaqmlp2qdd6f3vquwp0v5;
ALTER TABLE ONLY public.standard_group_has_mandate DROP CONSTRAINT fk_onmnajpvotgcd895vg0tcss2a;
ALTER TABLE ONLY public.standard_csn DROP CONSTRAINT fk_ndimff0ixagbxhc5l1lvi2ub1;
ALTER TABLE ONLY public.requirement DROP CONSTRAINT fk_mx2fl8ffv40qwaq5nvcmw1y6b;
ALTER TABLE ONLY public.report DROP CONSTRAINT fk_mpap9pjx2xb9qbwuh0scnsvw2;
ALTER TABLE ONLY public.mandate_has_changes DROP CONSTRAINT fk_m515qyvdoleoeriawem2vgibb;
ALTER TABLE ONLY public.standard_change DROP CONSTRAINT fk_lnu0tig6pmisdb68pogtan03l;
ALTER TABLE ONLY public.requirement DROP CONSTRAINT fk_kvu7dloejqvth7ne318h31huc;
ALTER TABLE ONLY public.standard DROP CONSTRAINT fk_j9fsjxwm48w1m9moat6vbe1xj;
ALTER TABLE ONLY public.portal_order DROP CONSTRAINT fk_j5p7na06bgelejw91af8x1x35;
ALTER TABLE ONLY public.commission_decision DROP CONSTRAINT fk_iqa31ers1cyku9wkgnrnhdmvu;
ALTER TABLE ONLY public.mandate_has_changes DROP CONSTRAINT fk_ibve81dw50a1p92mjh136l9ex;
ALTER TABLE ONLY public.notified_body DROP CONSTRAINT fk_i0n1qlljmtn83c2wqed3dcx8e;
ALTER TABLE ONLY public.standard_csn_has_change DROP CONSTRAINT fk_i0n07f03qrkhtilyl3vbrdodi;
ALTER TABLE ONLY public.user_info DROP CONSTRAINT fk_hixwjgx0ynne0cq4tqvoawoda;
ALTER TABLE ONLY public.notified_body DROP CONSTRAINT fk_hc5p5va1pmpwtrnp0t2j01l94;
ALTER TABLE ONLY public.standard_group DROP CONSTRAINT fk_gkgcaiwfkpti588ful21ol8ik;
ALTER TABLE ONLY public.standard DROP CONSTRAINT fk_fdjbg6kaey93ccbpr7x5rhbb8;
ALTER TABLE ONLY public.webpage DROP CONSTRAINT fk_fddggr2edrbye5lk53s29vj5q;
ALTER TABLE ONLY public.email_template DROP CONSTRAINT fk_f8eis4obuupn0wgi3pbh1qsth;
ALTER TABLE ONLY public.notified_body DROP CONSTRAINT fk_etyark37h3bq05h9d3gryr672;
ALTER TABLE ONLY public.standard_has_csn DROP CONSTRAINT fk_ef80oxh2fpae67i8986k5pcq6;
ALTER TABLE ONLY public.standard_has_notified_body DROP CONSTRAINT fk_eaqdsc67gam54qoi3m9oaevcq;
ALTER TABLE ONLY public.portal_product DROP CONSTRAINT fk_dbisqq23p4gj38mlscmsfuhj3;
ALTER TABLE ONLY public.commission_decision DROP CONSTRAINT fk_cstv0dod9eyftq6sy61if16h0;
ALTER TABLE ONLY public.standard_group DROP CONSTRAINT fk_cpid370p4nb8maq79x0xlcl1r;
ALTER TABLE ONLY public.webpage DROP CONSTRAINT fk_ckjftfsclfj5h45umpm61gul1;
ALTER TABLE ONLY public.report DROP CONSTRAINT fk_b1ohit61ufo3b2oq4btbvh35x;
ALTER TABLE ONLY public.notified_body DROP CONSTRAINT fk_ahl4iuqu9ahlrl4f06a2d65b;
ALTER TABLE ONLY public.user_has_online_publication DROP CONSTRAINT fk_9tu3mlf5j9oecnkpypw0eyyxg;
ALTER TABLE ONLY public.email_template DROP CONSTRAINT fk_9bdjqgopmkq9cl70fbwr39a6j;
ALTER TABLE ONLY public.portal_order DROP CONSTRAINT fk_8rb6uy7cjjq6rg8kb0a6f9q9c;
ALTER TABLE ONLY public.standard_change DROP CONSTRAINT fk_7myi2776jwujobisbhjyywjkj;
ALTER TABLE ONLY public.standard_group DROP CONSTRAINT fk_75otiiiitgh92frfkp184k9lt;
ALTER TABLE ONLY public.standard_csn DROP CONSTRAINT fk_6u1pm8t40m988rrxwhyc1juki;
ALTER TABLE ONLY public.portal_order_has_items DROP CONSTRAINT fk_6ph7ep7r2xgpq9nrah0fogtet;
ALTER TABLE ONLY public.webpage_content DROP CONSTRAINT fk_6k4i2jdt64328hsnqi0agy4n;
ALTER TABLE ONLY public.users_log DROP CONSTRAINT fk_5ycc2x7u9euxpes8hvqksygp0;
ALTER TABLE ONLY public.requirement DROP CONSTRAINT fk_54cys1kariva684yhcnda0m8s;
ALTER TABLE ONLY public.portal_product DROP CONSTRAINT fk_4w9x2vs83e5fwykw0vhow8frc;
ALTER TABLE ONLY public.standard_change DROP CONSTRAINT fk_49udthtt1cijmruv7sslabua6;
ALTER TABLE ONLY public.standard_is_in_standard_group DROP CONSTRAINT fk_3rlmxg1qhxy4aqitocnwr15ts;
ALTER TABLE ONLY public.standard_csn_has_change DROP CONSTRAINT fk_3r0y4dttn783u41ogony8fkoy;
ALTER TABLE ONLY public.standard_csn_has_change DROP CONSTRAINT fk_3qxxgge6ui0khvkrq8cnva8uw;
ALTER TABLE ONLY public.standard_has_notified_body DROP CONSTRAINT fk_3lvtpd1f6nocxyw8c225brv0t;
ALTER TABLE ONLY public.standard_group_has_mandate DROP CONSTRAINT fk_37dlhwuq5okdrf1101psyxtpw;
ALTER TABLE ONLY public.standard DROP CONSTRAINT fk_2irlnhxd5ivn3hl259y5e11ml;
ALTER TABLE ONLY public.user_has_online_publication DROP CONSTRAINT fk_1c21j4t3nn9ltf0e01bu5sjbc;
ALTER TABLE ONLY public.user_has_authority DROP CONSTRAINT fk98065a6a96a55a09;
ALTER TABLE ONLY public.user_has_authority DROP CONSTRAINT fk98065a6a8e81854b;
ALTER TABLE ONLY public.basic_requirement DROP CONSTRAINT fk881539b2fd0ba1a;
ALTER TABLE ONLY public.basic_requirement DROP CONSTRAINT fk881539b23f21b2ce;
ALTER TABLE ONLY public.users DROP CONSTRAINT fk6a68e08fd0ba1a;
ALTER TABLE ONLY public.users DROP CONSTRAINT fk6a68e083f21b2ce;
ALTER TABLE ONLY public.authority DROP CONSTRAINT fk57f40743fd0ba1a;
ALTER TABLE ONLY public.authority DROP CONSTRAINT fk57f407433f21b2ce;
ALTER TABLE ONLY public.csn_terminology_log DROP CONSTRAINT fk51e7df778e81854b;
ALTER TABLE ONLY public.csn_terminology_log DROP CONSTRAINT fk51e7df7748fdeb69;
ALTER TABLE ONLY public.country DROP CONSTRAINT fk39175796fd0ba1a;
ALTER TABLE ONLY public.country DROP CONSTRAINT fk391757963f21b2ce;
ALTER TABLE ONLY public.basic_settings DROP CONSTRAINT fk3075ed14fd0ba1a;
ALTER TABLE ONLY public.basic_settings DROP CONSTRAINT fk3075ed143f21b2ce;
ALTER TABLE ONLY public.csn_terminology DROP CONSTRAINT fk1c1b55f2fd0ba1a;
ALTER TABLE ONLY public.csn_terminology DROP CONSTRAINT fk1c1b55f248fdeb69;
ALTER TABLE ONLY public.csn_terminology DROP CONSTRAINT fk1c1b55f23f21b2ce;
ALTER TABLE ONLY public.csn DROP CONSTRAINT fk181fefd0ba1a;
ALTER TABLE ONLY public.csn DROP CONSTRAINT fk181fe648007c6;
ALTER TABLE ONLY public.csn DROP CONSTRAINT fk181fe3f21b2ce;
ALTER TABLE ONLY public.webpage DROP CONSTRAINT webpage_pkey;
ALTER TABLE ONLY public.webpage_content DROP CONSTRAINT webpage_content_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.users_log DROP CONSTRAINT users_log_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_email_key;
ALTER TABLE ONLY public.user_info DROP CONSTRAINT user_info_pkey;
ALTER TABLE ONLY public.user_has_online_publication DROP CONSTRAINT user_has_online_publication_pkey;
ALTER TABLE ONLY public.user_has_authority DROP CONSTRAINT user_has_authority_pkey;
ALTER TABLE ONLY public.standard_group_has_mandate DROP CONSTRAINT uk_37dlhwuq5okdrf1101psyxtpw;
ALTER TABLE ONLY public.standard DROP CONSTRAINT standard_pkey;
ALTER TABLE ONLY public.standard_is_in_standard_group DROP CONSTRAINT standard_is_in_standard_group_pkey;
ALTER TABLE ONLY public.standard_has_notified_body DROP CONSTRAINT standard_has_notified_body_pkey;
ALTER TABLE ONLY public.standard_has_csn DROP CONSTRAINT standard_has_csn_pkey;
ALTER TABLE ONLY public.standard_has_assessment_system DROP CONSTRAINT standard_has_assessment_system_pkey;
ALTER TABLE ONLY public.standard_group DROP CONSTRAINT standard_group_pkey;
ALTER TABLE ONLY public.standard_group_has_mandate DROP CONSTRAINT standard_group_has_mandate_pkey;
ALTER TABLE ONLY public.standard_csn DROP CONSTRAINT standard_csn_pkey;
ALTER TABLE ONLY public.standard_csn_has_change DROP CONSTRAINT standard_csn_has_change_pkey;
ALTER TABLE ONLY public.standard_change DROP CONSTRAINT standard_change_pkey;
ALTER TABLE ONLY public.requirement DROP CONSTRAINT requirement_pkey;
ALTER TABLE ONLY public.report DROP CONSTRAINT report_pkey;
ALTER TABLE ONLY public.portal_product DROP CONSTRAINT portal_product_pkey;
ALTER TABLE ONLY public.portal_order DROP CONSTRAINT portal_order_pkey;
ALTER TABLE ONLY public.portal_order_has_items DROP CONSTRAINT portal_order_has_items_pkey;
ALTER TABLE ONLY public.notified_body DROP CONSTRAINT notified_body_pkey;
ALTER TABLE ONLY public.mandate DROP CONSTRAINT mandate_pkey;
ALTER TABLE ONLY public.mandate_has_changes DROP CONSTRAINT mandate_has_changes_pkey;
ALTER TABLE ONLY public.exception_log DROP CONSTRAINT exception_log_pkey;
ALTER TABLE ONLY public.email_template DROP CONSTRAINT email_template_pkey;
ALTER TABLE ONLY public.csn_terminology DROP CONSTRAINT csn_terminology_pkey;
ALTER TABLE ONLY public.csn_terminology_log DROP CONSTRAINT csn_terminology_log_pkey;
ALTER TABLE ONLY public.csn DROP CONSTRAINT csn_pkey;
ALTER TABLE ONLY public.csn_category DROP CONSTRAINT csn_category_pkey;
ALTER TABLE ONLY public.country DROP CONSTRAINT country_pkey;
ALTER TABLE ONLY public.commission_decision DROP CONSTRAINT commission_decision_pkey;
ALTER TABLE ONLY public.basic_settings DROP CONSTRAINT basic_settings_pkey;
ALTER TABLE ONLY public.basic_requirement DROP CONSTRAINT basic_requirement_pkey;
ALTER TABLE ONLY public.authority DROP CONSTRAINT authority_pkey;
ALTER TABLE ONLY public.assessment_system DROP CONSTRAINT assessment_system_pkey;
ALTER TABLE ONLY public.article DROP CONSTRAINT article_pkey;
ALTER TABLE ONLY public.address DROP CONSTRAINT address_pkey;
DROP SEQUENCE public.webpage_id_seq;
DROP TABLE public.webpage_content;
DROP TABLE public.webpage;
DROP SEQUENCE public.users_log_id_seq;
DROP TABLE public.users_log;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP TABLE public.user_info;
DROP SEQUENCE public.user_has_online_publication_seq;
DROP TABLE public.user_has_online_publication;
DROP TABLE public.user_has_authority;
DROP TABLE public.standard_is_in_standard_group;
DROP SEQUENCE public.standard_id_seq;
DROP SEQUENCE public.standard_has_notified_body_id_seq;
DROP TABLE public.standard_has_notified_body;
DROP SEQUENCE public.standard_has_csn_id_seq;
DROP TABLE public.standard_has_csn;
DROP TABLE public.standard_has_assessment_system;
DROP SEQUENCE public.standard_group_id_seq;
DROP SEQUENCE public.standard_group_has_mandate_id_seq;
DROP TABLE public.standard_group_has_mandate;
DROP TABLE public.standard_group;
DROP TABLE public.standard_csn_has_change;
DROP SEQUENCE public.standard_csn_change_id_seq;
DROP TABLE public.standard_csn;
DROP SEQUENCE public.standard_change_id_seq;
DROP TABLE public.standard_change;
DROP TABLE public.standard;
DROP SEQUENCE public.requirement_id_seq;
DROP TABLE public.requirement;
DROP SEQUENCE public.report_id_seq;
DROP TABLE public.report;
DROP SEQUENCE public.portal_service_id_seq;
DROP TABLE public.portal_product;
DROP SEQUENCE public.portal_order_id_seq;
DROP TABLE public.portal_order_has_items;
DROP TABLE public.portal_order;
DROP SEQUENCE public.porta_order_item_seq;
DROP SEQUENCE public.notified_body_id_seq;
DROP TABLE public.notified_body;
DROP SEQUENCE public.mandate_id_seq;
DROP TABLE public.mandate_has_changes;
DROP TABLE public.mandate;
DROP SEQUENCE public.hibernate_sequence;
DROP SEQUENCE public.exception_log_id_seq;
DROP TABLE public.exception_log;
DROP SEQUENCE public.email_template_id_seq;
DROP TABLE public.email_template;
DROP SEQUENCE public.csn_terminology_log_id_seq;
DROP TABLE public.csn_terminology_log;
DROP SEQUENCE public.csn_terminology_id_seq;
DROP TABLE public.csn_terminology;
DROP SEQUENCE public.csn_id_seq;
DROP SEQUENCE public.csn_cateogry_id_seq;
DROP TABLE public.csn_category;
DROP TABLE public.csn;
DROP SEQUENCE public.country_id_seq;
DROP TABLE public.country;
DROP SEQUENCE public.commission_decision_id_seq;
DROP TABLE public.commission_decision;
DROP SEQUENCE public.basic_settings_id_seq;
DROP TABLE public.basic_settings;
DROP SEQUENCE public.basic_requirement_id_seq;
DROP TABLE public.basic_requirement;
DROP SEQUENCE public.authority_id_seq;
DROP TABLE public.authority;
DROP SEQUENCE public.assessment_system_id_seq;
DROP TABLE public.assessment_system;
DROP SEQUENCE public.article_id_seq;
DROP TABLE public.article;
DROP SEQUENCE public.address_id_seq;
DROP TABLE public.address;
DROP EXTENSION unaccent;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: itcuser
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO itcuser;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: itcuser
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: unaccent; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS unaccent WITH SCHEMA public;


--
-- Name: EXTENSION unaccent; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION unaccent IS 'text search dictionary that removes accents';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: address; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE address (
    id bigint NOT NULL,
    changed timestamp without time zone,
    code character varying(255),
    created timestamp without time zone,
    enabled boolean,
    city character varying(50),
    street character varying(100),
    zip character varying(6),
    id_user_changed_by bigint,
    id_user_created_by bigint
);


ALTER TABLE public.address OWNER TO postgres;

--
-- Name: address_id_seq; Type: SEQUENCE; Schema: public; Owner: itcuser
--

CREATE SEQUENCE address_id_seq
    START WITH 31
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.address_id_seq OWNER TO itcuser;

--
-- Name: article; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE article (
    id bigint NOT NULL,
    changed timestamp without time zone,
    code character varying(255),
    created timestamp without time zone,
    enabled boolean,
    article_content text,
    header character varying(255),
    published_since timestamp without time zone,
    published_until timestamp without time zone,
    title character varying(150),
    id_user_changed_by bigint,
    id_user_created_by bigint
);


ALTER TABLE public.article OWNER TO postgres;

--
-- Name: article_id_seq; Type: SEQUENCE; Schema: public; Owner: itcuser
--

CREATE SEQUENCE article_id_seq
    START WITH 7
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.article_id_seq OWNER TO itcuser;

--
-- Name: assessment_system; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE assessment_system (
    id bigint NOT NULL,
    changed timestamp without time zone,
    code character varying(255),
    created timestamp without time zone,
    enabled boolean,
    system_code character varying(20),
    dop_text text,
    description text,
    name character varying(75) NOT NULL,
    id_user_changed_by bigint,
    id_user_created_by bigint
);


ALTER TABLE public.assessment_system OWNER TO postgres;

--
-- Name: assessment_system_id_seq; Type: SEQUENCE; Schema: public; Owner: itcuser
--

CREATE SEQUENCE assessment_system_id_seq
    START WITH 14
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.assessment_system_id_seq OWNER TO itcuser;

--
-- Name: authority; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE authority (
    id bigint NOT NULL,
    changed timestamp without time zone,
    code character varying(255),
    created timestamp without time zone,
    enabled boolean,
    long_description text,
    name character varying(45),
    short_description character varying(255),
    id_user_changed_by bigint,
    id_user_created_by bigint
);


ALTER TABLE public.authority OWNER TO postgres;

--
-- Name: authority_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE authority_id_seq
    START WITH 4
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.authority_id_seq OWNER TO postgres;

--
-- Name: basic_requirement; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE basic_requirement (
    id bigint NOT NULL,
    changed timestamp without time zone,
    code character varying(255),
    created timestamp without time zone,
    enabled boolean,
    description text,
    name character varying(150) NOT NULL,
    id_user_changed_by bigint,
    id_user_created_by bigint
);


ALTER TABLE public.basic_requirement OWNER TO postgres;

--
-- Name: basic_requirement_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE basic_requirement_id_seq
    START WITH 8
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.basic_requirement_id_seq OWNER TO postgres;

--
-- Name: basic_settings; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE basic_settings (
    id bigint NOT NULL,
    changed timestamp without time zone,
    code character varying(255),
    created timestamp without time zone,
    enabled boolean,
    main_system_email character varying(50),
    id_user_changed_by bigint,
    id_user_created_by bigint,
    version character varying(30),
    city character varying(50),
    company_name character varying(100),
    cz_account_number character varying(25),
    cz_iban character varying(34),
    cz_swift character varying(8),
    dic character varying(10),
    eu_account_number character varying(25),
    eu_iban character varying(34),
    eu_swift character varying(8),
    ico character varying(10),
    invoice_email character varying(35),
    phone character varying(20),
    street character varying(80),
    zip character varying(6),
    plastic_portal_email character varying(40),
    portal_admin_contacts character varying(80),
    portal_admin_name character varying(50)
);


ALTER TABLE public.basic_settings OWNER TO postgres;

--
-- Name: basic_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE basic_settings_id_seq
    START WITH 2
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.basic_settings_id_seq OWNER TO postgres;

--
-- Name: commission_decision; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE commission_decision (
    id bigint NOT NULL,
    changed timestamp without time zone,
    code character varying(255),
    created timestamp without time zone,
    enabled boolean,
    consolidated_version boolean,
    czech_file_url character varying(150),
    czech_label character varying(20) NOT NULL,
    draftamendmentlabel character varying(255),
    draft_amendment_file_url character varying(150),
    english_file_url character varying(150),
    english_label character varying(20),
    id_user_changed_by bigint,
    id_user_created_by bigint
);


ALTER TABLE public.commission_decision OWNER TO postgres;

--
-- Name: commission_decision_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE commission_decision_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.commission_decision_id_seq OWNER TO postgres;

--
-- Name: country; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE country (
    id bigint NOT NULL,
    changed timestamp without time zone,
    code character varying(255),
    created timestamp without time zone,
    enabled boolean,
    country_name character varying(45),
    id_user_changed_by bigint,
    id_user_created_by bigint
);


ALTER TABLE public.country OWNER TO postgres;

--
-- Name: country_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE country_id_seq
    START WITH 4
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.country_id_seq OWNER TO postgres;

--
-- Name: csn; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE csn (
    id bigint NOT NULL,
    changed timestamp without time zone,
    code character varying(255),
    created timestamp without time zone,
    enabled boolean,
    classification_symbol character varying(10),
    csn_id character varying(50),
    csnonline_id character varying(10),
    czech_name character varying(350),
    english_name character varying(255),
    file_name character varying(64),
    ics character varying(255),
    id_user_changed_by bigint,
    id_user_created_by bigint,
    csn_category_id bigint,
    label_of_change character varying(25),
    category_search_code character varying(4),
    published date
);


ALTER TABLE public.csn OWNER TO postgres;

--
-- Name: csn_category; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE csn_category (
    id bigint NOT NULL,
    changed timestamp without time zone,
    code character varying(255),
    created timestamp without time zone,
    enabled boolean,
    name character varying(255),
    searchcode character varying(255),
    id_user_changed_by bigint,
    id_user_created_by bigint,
    parent_id bigint
);


ALTER TABLE public.csn_category OWNER TO postgres;

--
-- Name: csn_cateogry_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE csn_cateogry_id_seq
    START WITH 6
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.csn_cateogry_id_seq OWNER TO postgres;

--
-- Name: csn_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE csn_id_seq
    START WITH 10
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.csn_id_seq OWNER TO postgres;

--
-- Name: csn_terminology; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE csn_terminology (
    id bigint NOT NULL,
    changed timestamp without time zone,
    code character varying(255),
    created timestamp without time zone,
    enabled boolean,
    content text,
    lang character varying(2),
    section character varying(25),
    title character varying(300),
    id_user_changed_by bigint,
    id_user_created_by bigint,
    csn_id bigint
);


ALTER TABLE public.csn_terminology OWNER TO postgres;

--
-- Name: csn_terminology_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE csn_terminology_id_seq
    START WITH 33
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.csn_terminology_id_seq OWNER TO postgres;

--
-- Name: csn_terminology_log; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE csn_terminology_log (
    id bigint NOT NULL,
    created timestamp without time zone,
    cz_count integer,
    description text,
    en_count integer,
    success boolean,
    duration bigint NOT NULL,
    file_name character varying(30),
    count_of_images integer,
    user_id bigint,
    csn_id bigint,
    import_status character varying(15)
);


ALTER TABLE public.csn_terminology_log OWNER TO postgres;

--
-- Name: csn_terminology_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE csn_terminology_log_id_seq
    START WITH 14
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.csn_terminology_log_id_seq OWNER TO postgres;

--
-- Name: email_template; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE email_template (
    id bigint NOT NULL,
    changed timestamp without time zone,
    code character varying(255),
    created timestamp without time zone,
    enabled boolean,
    body text,
    name character varying(100),
    subject character varying(150),
    variables character varying(300),
    variable_description text,
    id_user_changed_by bigint,
    id_user_created_by bigint,
    bcc_forwarding character varying(255)
);


ALTER TABLE public.email_template OWNER TO postgres;

--
-- Name: email_template_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE email_template_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 10000
    CACHE 1;


ALTER TABLE public.email_template_id_seq OWNER TO postgres;

--
-- Name: exception_log; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exception_log (
    id bigint NOT NULL,
    created timestamp without time zone,
    mehtod character varying(255),
    message text,
    referer character varying(255),
    stack_trace text,
    type character varying(255),
    url character varying(255),
    user_id bigint,
    query_params text,
    request_headers text,
    request_params text
);


ALTER TABLE public.exception_log OWNER TO postgres;

--
-- Name: exception_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exception_log_id_seq
    START WITH 42
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.exception_log_id_seq OWNER TO postgres;

--
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hibernate_sequence OWNER TO postgres;

--
-- Name: mandate; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE mandate (
    id bigint NOT NULL,
    changed timestamp without time zone,
    code character varying(255),
    created timestamp without time zone,
    enabled boolean,
    mandate_file_url character varying(255),
    mandate_name character varying(25) NOT NULL,
    id_user_changed_by bigint,
    id_user_created_by bigint
);


ALTER TABLE public.mandate OWNER TO postgres;

--
-- Name: mandate_has_changes; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE mandate_has_changes (
    mandate_id bigint NOT NULL,
    mandate_change_id bigint NOT NULL
);


ALTER TABLE public.mandate_has_changes OWNER TO postgres;

--
-- Name: mandate_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE mandate_id_seq
    START WITH 11
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mandate_id_seq OWNER TO postgres;

--
-- Name: notified_body; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE notified_body (
    id bigint NOT NULL,
    changed timestamp without time zone,
    code character varying(255),
    created timestamp without time zone,
    enabled boolean,
    description text,
    email character varying(45),
    is_eta_certification_allowed boolean,
    fax character varying(20),
    name character varying(200),
    no_code character varying(25) NOT NULL,
    phone character varying(20),
    web character varying(100),
    id_user_changed_by bigint,
    id_user_created_by bigint,
    address_id bigint,
    country_id bigint,
    ao_code character varying(25),
    nando_code character varying(255),
    city character varying(50),
    street character varying(100),
    zip character varying(6)
);


ALTER TABLE public.notified_body OWNER TO postgres;

--
-- Name: notified_body_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE notified_body_id_seq
    START WITH 29
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notified_body_id_seq OWNER TO postgres;

--
-- Name: porta_order_item_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE porta_order_item_seq
    START WITH 221
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.porta_order_item_seq OWNER TO postgres;

--
-- Name: portal_order; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE portal_order (
    id bigint NOT NULL,
    changed timestamp without time zone,
    code character varying(255),
    created timestamp without time zone,
    enabled boolean,
    city character varying(50),
    company_name character varying(50),
    currency character varying(3) NOT NULL,
    date_of_activation date,
    dic character varying(15),
    email character varying(50),
    email_sent boolean,
    first_name character varying(50) NOT NULL,
    ico character varying(8),
    ip_address character varying(45),
    last_name character varying(50) NOT NULL,
    order_status character varying(25),
    phone character varying(25),
    order_source character varying(15),
    street character varying(50),
    vat numeric(3,2),
    zip character varying(6),
    id_user_changed_by bigint,
    id_user_created_by bigint,
    user_id bigint NOT NULL,
    referer character varying(250),
    user_agent character varying(150),
    portal_country character varying(2) NOT NULL,
    duzp character varying(10)
);


ALTER TABLE public.portal_order OWNER TO postgres;

--
-- Name: portal_order_has_items; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE portal_order_has_items (
    id bigint NOT NULL,
    price numeric(6,2) NOT NULL,
    portal_order_id bigint NOT NULL,
    portal_product_id bigint NOT NULL,
    CONSTRAINT portal_order_has_items_price_check CHECK (((price >= (0)::numeric) AND (price <= (100000)::numeric)))
);


ALTER TABLE public.portal_order_has_items OWNER TO postgres;

--
-- Name: portal_order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE portal_order_id_seq
    START WITH 11050
    INCREMENT BY 1
    MINVALUE 11000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.portal_order_id_seq OWNER TO postgres;

--
-- Name: portal_product; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE portal_product (
    id bigint NOT NULL,
    changed timestamp without time zone,
    code character varying(255),
    created timestamp without time zone,
    enabled boolean,
    czech_name character varying(150),
    deleted boolean NOT NULL,
    description_czech text,
    description_english text,
    english_name character varying(150),
    interval_value integer,
    online_publication character varying(20),
    interval_type character varying(10),
    portal_product_type character varying(12),
    price_czk numeric(6,0) NOT NULL,
    price_eur numeric(6,0) NOT NULL,
    id_user_changed_by bigint,
    id_user_created_by bigint,
    CONSTRAINT portal_product_interval_value_check CHECK (((interval_value >= 1) AND (interval_value <= 100))),
    CONSTRAINT portal_product_price_czk_check CHECK (((price_czk <= (100000)::numeric) AND (price_czk >= (0)::numeric))),
    CONSTRAINT portal_product_price_eur_check CHECK (((price_eur <= (100000)::numeric) AND (price_eur >= (0)::numeric)))
);


ALTER TABLE public.portal_product OWNER TO postgres;

--
-- Name: portal_service_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE portal_service_id_seq
    START WITH 221
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.portal_service_id_seq OWNER TO postgres;

--
-- Name: report; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE report (
    id bigint NOT NULL,
    changed timestamp without time zone,
    created timestamp without time zone,
    enabled boolean,
    content_czech text,
    content_english text,
    date_from date,
    date_to date,
    id_user_changed_by bigint,
    id_user_created_by bigint,
    code character varying(255)
);


ALTER TABLE public.report OWNER TO postgres;

--
-- Name: report_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE report_id_seq
    START WITH 221
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.report_id_seq OWNER TO postgres;

--
-- Name: requirement; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE requirement (
    id bigint NOT NULL,
    changed timestamp without time zone,
    code character varying(255),
    created timestamp without time zone,
    enabled boolean,
    levels character varying(50),
    name character varying(100),
    note character varying(150),
    npd boolean,
    section character varying(50),
    id_user_changed_by bigint,
    id_user_created_by bigint,
    country_id bigint,
    standard_id bigint
);


ALTER TABLE public.requirement OWNER TO postgres;

--
-- Name: requirement_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE requirement_id_seq
    START WITH 37
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.requirement_id_seq OWNER TO postgres;

--
-- Name: standard; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE standard (
    id bigint NOT NULL,
    changed timestamp without time zone,
    code character varying(255),
    created timestamp without time zone,
    enabled boolean,
    is_cumulative boolean,
    czech_name character varying(300),
    english_name character varying(300),
    replaced_standard_code character varying(45),
    standard_id character varying(45) NOT NULL,
    standard_status character varying(25),
    start_validity date,
    status_date date,
    stop_validity date,
    text text,
    id_user_changed_by bigint,
    id_user_created_by bigint,
    replaced_standard_id bigint,
    released_date date
);


ALTER TABLE public.standard OWNER TO postgres;

--
-- Name: standard_change; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE standard_change (
    id bigint NOT NULL,
    changed timestamp without time zone,
    code character varying(255),
    created timestamp without time zone,
    enabled boolean,
    change_code character varying(255),
    change_note character varying(255),
    start_validity date,
    stop_validity date,
    id_user_changed_by bigint,
    id_user_created_by bigint,
    standard_id bigint
);


ALTER TABLE public.standard_change OWNER TO postgres;

--
-- Name: standard_change_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE standard_change_id_seq
    START WITH 42
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.standard_change_id_seq OWNER TO postgres;

--
-- Name: standard_csn; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE standard_csn (
    id bigint NOT NULL,
    changed timestamp without time zone,
    code character varying(255),
    created timestamp without time zone,
    enabled boolean,
    classification_symbol character varying(10),
    csn_name character varying(45) NOT NULL,
    csn_online_id character varying(10),
    note character varying(255),
    standard_status character varying(25),
    status_date date,
    id_user_changed_by bigint,
    id_user_created_by bigint,
    replaced_standard_csn_id bigint,
    released_date date
);


ALTER TABLE public.standard_csn OWNER TO postgres;

--
-- Name: standard_csn_change_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE standard_csn_change_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.standard_csn_change_id_seq OWNER TO postgres;

--
-- Name: standard_csn_has_change; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE standard_csn_has_change (
    id bigint NOT NULL,
    changed timestamp without time zone,
    code character varying(255),
    created timestamp without time zone,
    enabled boolean,
    csn_name character varying(255) NOT NULL,
    csn_online_id character varying(10),
    status_date date,
    note character varying(255),
    id_user_changed_by bigint,
    id_user_created_by bigint,
    standard_id bigint,
    released_date date,
    standard_status character varying(25)
);


ALTER TABLE public.standard_csn_has_change OWNER TO postgres;

--
-- Name: standard_group; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE standard_group (
    id bigint NOT NULL,
    changed timestamp without time zone,
    code character varying(255),
    created timestamp without time zone,
    enabled boolean,
    czech_name character varying(255) NOT NULL,
    english_name character varying(255),
    id_user_changed_by bigint,
    id_user_created_by bigint,
    commission_decision_id bigint
);


ALTER TABLE public.standard_group OWNER TO postgres;

--
-- Name: standard_group_has_mandate; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE standard_group_has_mandate (
    standard_group_id bigint NOT NULL,
    mandates_id bigint NOT NULL
);


ALTER TABLE public.standard_group_has_mandate OWNER TO postgres;

--
-- Name: standard_group_has_mandate_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE standard_group_has_mandate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.standard_group_has_mandate_id_seq OWNER TO postgres;

--
-- Name: standard_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE standard_group_id_seq
    START WITH 36
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.standard_group_id_seq OWNER TO postgres;

--
-- Name: standard_has_assessment_system; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE standard_has_assessment_system (
    standard_id bigint NOT NULL,
    notified_body_id bigint NOT NULL
);


ALTER TABLE public.standard_has_assessment_system OWNER TO postgres;

--
-- Name: standard_has_csn; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE standard_has_csn (
    standard_id bigint NOT NULL,
    standard_csn_id bigint NOT NULL
);


ALTER TABLE public.standard_has_csn OWNER TO postgres;

--
-- Name: standard_has_csn_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE standard_has_csn_id_seq
    START WITH 46
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.standard_has_csn_id_seq OWNER TO postgres;

--
-- Name: standard_has_notified_body; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE standard_has_notified_body (
    standard_id bigint NOT NULL,
    notified_body_id bigint NOT NULL,
    id bigint,
    assignment_date date
);


ALTER TABLE public.standard_has_notified_body OWNER TO postgres;

--
-- Name: standard_has_notified_body_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE standard_has_notified_body_id_seq
    START WITH 221
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.standard_has_notified_body_id_seq OWNER TO postgres;

--
-- Name: standard_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE standard_id_seq
    START WITH 42
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.standard_id_seq OWNER TO postgres;

--
-- Name: standard_is_in_standard_group; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE standard_is_in_standard_group (
    standard_id bigint NOT NULL,
    standard_group_id bigint NOT NULL
);


ALTER TABLE public.standard_is_in_standard_group OWNER TO postgres;

--
-- Name: user_has_authority; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE user_has_authority (
    user_id bigint NOT NULL,
    authority_id bigint NOT NULL
);


ALTER TABLE public.user_has_authority OWNER TO postgres;

--
-- Name: user_has_online_publication; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE user_has_online_publication (
    id bigint NOT NULL,
    changed timestamp without time zone,
    created timestamp without time zone,
    validity date NOT NULL,
    portal_product_id bigint NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.user_has_online_publication OWNER TO postgres;

--
-- Name: user_has_online_publication_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE user_has_online_publication_seq
    START WITH 221
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_has_online_publication_seq OWNER TO postgres;

--
-- Name: user_info; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE user_info (
    city character varying(50),
    company_name character varying(50),
    dic character varying(15),
    ico character varying(15),
    phone character varying(25),
    street character varying(50),
    zip character varying(6),
    user_id bigint NOT NULL,
    sgp_sync_ok boolean,
    portal_country character varying(2) NOT NULL
);


ALTER TABLE public.user_info OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE users (
    id bigint NOT NULL,
    changed timestamp without time zone,
    code character varying(255),
    created timestamp without time zone,
    enabled boolean,
    email character varying(50),
    first_name character varying(50),
    last_name character varying(50),
    password character varying(60),
    id_user_changed_by bigint,
    id_user_created_by bigint,
    change_pass_req_date timestamp without time zone,
    change_pass_req_token character varying(60),
    registration_validity date,
    sgp_password character varying(48)
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE users_id_seq
    START WITH 32
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_log; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE users_log (
    id bigint NOT NULL,
    ip_address character varying(100),
    login_date timestamp without time zone,
    login_success boolean,
    logout_date timestamp without time zone,
    session_id character varying(100),
    user_name character varying(50),
    id_user bigint
);


ALTER TABLE public.users_log OWNER TO postgres;

--
-- Name: users_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE users_log_id_seq
    START WITH 341
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_log_id_seq OWNER TO postgres;

--
-- Name: webpage; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE webpage (
    id bigint NOT NULL,
    changed timestamp without time zone,
    code character varying(255),
    created timestamp without time zone,
    enabled boolean,
    avatar character varying(100),
    is_locked boolean,
    webpage_order integer,
    published_since timestamp without time zone,
    redirect_url character varying(255),
    webpage_type character varying(25),
    id_user_changed_by bigint,
    id_user_created_by bigint,
    parent_id bigint,
    redirect_webpage_id bigint,
    is_locked_code boolean,
    is_locked_remove boolean,
    webpage_modlue character varying(30),
    show_thumb boolean,
    only_for_registraged boolean DEFAULT false NOT NULL,
    full_page_width boolean,
    hit bigint
);


ALTER TABLE public.webpage OWNER TO postgres;

--
-- Name: webpage_content; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE webpage_content (
    webpage_id bigint NOT NULL,
    content text,
    description text,
    name character varying(200) NOT NULL,
    title character varying(250),
    url character varying(255),
    localized_key character varying(255) NOT NULL
);


ALTER TABLE public.webpage_content OWNER TO postgres;

--
-- Name: webpage_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE webpage_id_seq
    START WITH 14
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.webpage_id_seq OWNER TO postgres;

--
-- Data for Name: address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY address (id, changed, code, created, enabled, city, street, zip, id_user_changed_by, id_user_created_by) FROM stdin;
\.
COPY address (id, changed, code, created, enabled, city, street, zip, id_user_changed_by, id_user_created_by) FROM '$$PATH$$/2393.dat';

--
-- Name: address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: itcuser
--

SELECT pg_catalog.setval('address_id_seq', 31, true);


--
-- Data for Name: article; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY article (id, changed, code, created, enabled, article_content, header, published_since, published_until, title, id_user_changed_by, id_user_created_by) FROM stdin;
\.
COPY article (id, changed, code, created, enabled, article_content, header, published_since, published_until, title, id_user_changed_by, id_user_created_by) FROM '$$PATH$$/2395.dat';

--
-- Name: article_id_seq; Type: SEQUENCE SET; Schema: public; Owner: itcuser
--

SELECT pg_catalog.setval('article_id_seq', 7, true);


--
-- Data for Name: assessment_system; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY assessment_system (id, changed, code, created, enabled, system_code, dop_text, description, name, id_user_changed_by, id_user_created_by) FROM stdin;
\.
COPY assessment_system (id, changed, code, created, enabled, system_code, dop_text, description, name, id_user_changed_by, id_user_created_by) FROM '$$PATH$$/2397.dat';

--
-- Name: assessment_system_id_seq; Type: SEQUENCE SET; Schema: public; Owner: itcuser
--

SELECT pg_catalog.setval('assessment_system_id_seq', 14, true);


--
-- Data for Name: authority; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY authority (id, changed, code, created, enabled, long_description, name, short_description, id_user_changed_by, id_user_created_by) FROM stdin;
\.
COPY authority (id, changed, code, created, enabled, long_description, name, short_description, id_user_changed_by, id_user_created_by) FROM '$$PATH$$/2399.dat';

--
-- Name: authority_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('authority_id_seq', 4, true);


--
-- Data for Name: basic_requirement; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY basic_requirement (id, changed, code, created, enabled, description, name, id_user_changed_by, id_user_created_by) FROM stdin;
\.
COPY basic_requirement (id, changed, code, created, enabled, description, name, id_user_changed_by, id_user_created_by) FROM '$$PATH$$/2401.dat';

--
-- Name: basic_requirement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('basic_requirement_id_seq', 8, true);


--
-- Data for Name: basic_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY basic_settings (id, changed, code, created, enabled, main_system_email, id_user_changed_by, id_user_created_by, version, city, company_name, cz_account_number, cz_iban, cz_swift, dic, eu_account_number, eu_iban, eu_swift, ico, invoice_email, phone, street, zip, plastic_portal_email, portal_admin_contacts, portal_admin_name) FROM stdin;
\.
COPY basic_settings (id, changed, code, created, enabled, main_system_email, id_user_changed_by, id_user_created_by, version, city, company_name, cz_account_number, cz_iban, cz_swift, dic, eu_account_number, eu_iban, eu_swift, ico, invoice_email, phone, street, zip, plastic_portal_email, portal_admin_contacts, portal_admin_name) FROM '$$PATH$$/2403.dat';

--
-- Name: basic_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('basic_settings_id_seq', 2, true);


--
-- Data for Name: commission_decision; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY commission_decision (id, changed, code, created, enabled, consolidated_version, czech_file_url, czech_label, draftamendmentlabel, draft_amendment_file_url, english_file_url, english_label, id_user_changed_by, id_user_created_by) FROM stdin;
\.
COPY commission_decision (id, changed, code, created, enabled, consolidated_version, czech_file_url, czech_label, draftamendmentlabel, draft_amendment_file_url, english_file_url, english_label, id_user_changed_by, id_user_created_by) FROM '$$PATH$$/2405.dat';

--
-- Name: commission_decision_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('commission_decision_id_seq', 111, true);


--
-- Data for Name: country; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY country (id, changed, code, created, enabled, country_name, id_user_changed_by, id_user_created_by) FROM stdin;
\.
COPY country (id, changed, code, created, enabled, country_name, id_user_changed_by, id_user_created_by) FROM '$$PATH$$/2407.dat';

--
-- Name: country_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('country_id_seq', 4, true);


--
-- Data for Name: csn; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY csn (id, changed, code, created, enabled, classification_symbol, csn_id, csnonline_id, czech_name, english_name, file_name, ics, id_user_changed_by, id_user_created_by, csn_category_id, label_of_change, category_search_code, published) FROM stdin;
\.
COPY csn (id, changed, code, created, enabled, classification_symbol, csn_id, csnonline_id, czech_name, english_name, file_name, ics, id_user_changed_by, id_user_created_by, csn_category_id, label_of_change, category_search_code, published) FROM '$$PATH$$/2409.dat';

--
-- Data for Name: csn_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY csn_category (id, changed, code, created, enabled, name, searchcode, id_user_changed_by, id_user_created_by, parent_id) FROM stdin;
\.
COPY csn_category (id, changed, code, created, enabled, name, searchcode, id_user_changed_by, id_user_created_by, parent_id) FROM '$$PATH$$/2410.dat';

--
-- Name: csn_cateogry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('csn_cateogry_id_seq', 6, true);


--
-- Name: csn_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('csn_id_seq', 3954, true);


--
-- Data for Name: csn_terminology; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY csn_terminology (id, changed, code, created, enabled, content, lang, section, title, id_user_changed_by, id_user_created_by, csn_id) FROM stdin;
\.
COPY csn_terminology (id, changed, code, created, enabled, content, lang, section, title, id_user_changed_by, id_user_created_by, csn_id) FROM '$$PATH$$/2413.dat';

--
-- Name: csn_terminology_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('csn_terminology_id_seq', 32042, true);


--
-- Data for Name: csn_terminology_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY csn_terminology_log (id, created, cz_count, description, en_count, success, duration, file_name, count_of_images, user_id, csn_id, import_status) FROM stdin;
\.
COPY csn_terminology_log (id, created, cz_count, description, en_count, success, duration, file_name, count_of_images, user_id, csn_id, import_status) FROM '$$PATH$$/2415.dat';

--
-- Name: csn_terminology_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('csn_terminology_log_id_seq', 68, true);


--
-- Data for Name: email_template; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY email_template (id, changed, code, created, enabled, body, name, subject, variables, variable_description, id_user_changed_by, id_user_created_by, bcc_forwarding) FROM stdin;
\.
COPY email_template (id, changed, code, created, enabled, body, name, subject, variables, variable_description, id_user_changed_by, id_user_created_by, bcc_forwarding) FROM '$$PATH$$/2464.dat';

--
-- Name: email_template_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('email_template_id_seq', 1, false);


--
-- Data for Name: exception_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY exception_log (id, created, mehtod, message, referer, stack_trace, type, url, user_id, query_params, request_headers, request_params) FROM stdin;
\.
COPY exception_log (id, created, mehtod, message, referer, stack_trace, type, url, user_id, query_params, request_headers, request_params) FROM '$$PATH$$/2417.dat';

--
-- Name: exception_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exception_log_id_seq', 171, true);


--
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('hibernate_sequence', 2879, true);


--
-- Data for Name: mandate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mandate (id, changed, code, created, enabled, mandate_file_url, mandate_name, id_user_changed_by, id_user_created_by) FROM stdin;
\.
COPY mandate (id, changed, code, created, enabled, mandate_file_url, mandate_name, id_user_changed_by, id_user_created_by) FROM '$$PATH$$/2420.dat';

--
-- Data for Name: mandate_has_changes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mandate_has_changes (mandate_id, mandate_change_id) FROM stdin;
\.
COPY mandate_has_changes (mandate_id, mandate_change_id) FROM '$$PATH$$/2421.dat';

--
-- Name: mandate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('mandate_id_seq', 198, true);


--
-- Data for Name: notified_body; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY notified_body (id, changed, code, created, enabled, description, email, is_eta_certification_allowed, fax, name, no_code, phone, web, id_user_changed_by, id_user_created_by, address_id, country_id, ao_code, nando_code, city, street, zip) FROM stdin;
\.
COPY notified_body (id, changed, code, created, enabled, description, email, is_eta_certification_allowed, fax, name, no_code, phone, web, id_user_changed_by, id_user_created_by, address_id, country_id, ao_code, nando_code, city, street, zip) FROM '$$PATH$$/2423.dat';

--
-- Name: notified_body_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('notified_body_id_seq', 29, true);


--
-- Name: porta_order_item_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('porta_order_item_seq', 231, true);


--
-- Data for Name: portal_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY portal_order (id, changed, code, created, enabled, city, company_name, currency, date_of_activation, dic, email, email_sent, first_name, ico, ip_address, last_name, order_status, phone, order_source, street, vat, zip, id_user_changed_by, id_user_created_by, user_id, referer, user_agent, portal_country, duzp) FROM stdin;
\.
COPY portal_order (id, changed, code, created, enabled, city, company_name, currency, date_of_activation, dic, email, email_sent, first_name, ico, ip_address, last_name, order_status, phone, order_source, street, vat, zip, id_user_changed_by, id_user_created_by, user_id, referer, user_agent, portal_country, duzp) FROM '$$PATH$$/2459.dat';

--
-- Data for Name: portal_order_has_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY portal_order_has_items (id, price, portal_order_id, portal_product_id) FROM stdin;
\.
COPY portal_order_has_items (id, price, portal_order_id, portal_product_id) FROM '$$PATH$$/2461.dat';

--
-- Name: portal_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('portal_order_id_seq', 553200001, true);


--
-- Data for Name: portal_product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY portal_product (id, changed, code, created, enabled, czech_name, deleted, description_czech, description_english, english_name, interval_value, online_publication, interval_type, portal_product_type, price_czk, price_eur, id_user_changed_by, id_user_created_by) FROM stdin;
\.
COPY portal_product (id, changed, code, created, enabled, czech_name, deleted, description_czech, description_english, english_name, interval_value, online_publication, interval_type, portal_product_type, price_czk, price_eur, id_user_changed_by, id_user_created_by) FROM '$$PATH$$/2460.dat';

--
-- Name: portal_service_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('portal_service_id_seq', 221, false);


--
-- Data for Name: report; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY report (id, changed, created, enabled, content_czech, content_english, date_from, date_to, id_user_changed_by, id_user_created_by, code) FROM stdin;
\.
COPY report (id, changed, created, enabled, content_czech, content_english, date_from, date_to, id_user_changed_by, id_user_created_by, code) FROM '$$PATH$$/2451.dat';

--
-- Name: report_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('report_id_seq', 223, true);


--
-- Data for Name: requirement; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY requirement (id, changed, code, created, enabled, levels, name, note, npd, section, id_user_changed_by, id_user_created_by, country_id, standard_id) FROM stdin;
\.
COPY requirement (id, changed, code, created, enabled, levels, name, note, npd, section, id_user_changed_by, id_user_created_by, country_id, standard_id) FROM '$$PATH$$/2425.dat';

--
-- Name: requirement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('requirement_id_seq', 37, true);


--
-- Data for Name: standard; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY standard (id, changed, code, created, enabled, is_cumulative, czech_name, english_name, replaced_standard_code, standard_id, standard_status, start_validity, status_date, stop_validity, text, id_user_changed_by, id_user_created_by, replaced_standard_id, released_date) FROM stdin;
\.
COPY standard (id, changed, code, created, enabled, is_cumulative, czech_name, english_name, replaced_standard_code, standard_id, standard_status, start_validity, status_date, stop_validity, text, id_user_changed_by, id_user_created_by, replaced_standard_id, released_date) FROM '$$PATH$$/2427.dat';

--
-- Data for Name: standard_change; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY standard_change (id, changed, code, created, enabled, change_code, change_note, start_validity, stop_validity, id_user_changed_by, id_user_created_by, standard_id) FROM stdin;
\.
COPY standard_change (id, changed, code, created, enabled, change_code, change_note, start_validity, stop_validity, id_user_changed_by, id_user_created_by, standard_id) FROM '$$PATH$$/2428.dat';

--
-- Name: standard_change_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('standard_change_id_seq', 146, true);


--
-- Data for Name: standard_csn; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY standard_csn (id, changed, code, created, enabled, classification_symbol, csn_name, csn_online_id, note, standard_status, status_date, id_user_changed_by, id_user_created_by, replaced_standard_csn_id, released_date) FROM stdin;
\.
COPY standard_csn (id, changed, code, created, enabled, classification_symbol, csn_name, csn_online_id, note, standard_status, status_date, id_user_changed_by, id_user_created_by, replaced_standard_csn_id, released_date) FROM '$$PATH$$/2430.dat';

--
-- Name: standard_csn_change_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('standard_csn_change_id_seq', 185, true);


--
-- Data for Name: standard_csn_has_change; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY standard_csn_has_change (id, changed, code, created, enabled, csn_name, csn_online_id, status_date, note, id_user_changed_by, id_user_created_by, standard_id, released_date, standard_status) FROM stdin;
\.
COPY standard_csn_has_change (id, changed, code, created, enabled, csn_name, csn_online_id, status_date, note, id_user_changed_by, id_user_created_by, standard_id, released_date, standard_status) FROM '$$PATH$$/2432.dat';

--
-- Data for Name: standard_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY standard_group (id, changed, code, created, enabled, czech_name, english_name, id_user_changed_by, id_user_created_by, commission_decision_id) FROM stdin;
\.
COPY standard_group (id, changed, code, created, enabled, czech_name, english_name, id_user_changed_by, id_user_created_by, commission_decision_id) FROM '$$PATH$$/2433.dat';

--
-- Data for Name: standard_group_has_mandate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY standard_group_has_mandate (standard_group_id, mandates_id) FROM stdin;
\.
COPY standard_group_has_mandate (standard_group_id, mandates_id) FROM '$$PATH$$/2434.dat';

--
-- Name: standard_group_has_mandate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('standard_group_has_mandate_id_seq', 79, true);


--
-- Name: standard_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('standard_group_id_seq', 168, true);


--
-- Data for Name: standard_has_assessment_system; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY standard_has_assessment_system (standard_id, notified_body_id) FROM stdin;
\.
COPY standard_has_assessment_system (standard_id, notified_body_id) FROM '$$PATH$$/2437.dat';

--
-- Data for Name: standard_has_csn; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY standard_has_csn (standard_id, standard_csn_id) FROM stdin;
\.
COPY standard_has_csn (standard_id, standard_csn_id) FROM '$$PATH$$/2438.dat';

--
-- Name: standard_has_csn_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('standard_has_csn_id_seq', 483, true);


--
-- Data for Name: standard_has_notified_body; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY standard_has_notified_body (standard_id, notified_body_id, id, assignment_date) FROM stdin;
\.
COPY standard_has_notified_body (standard_id, notified_body_id, id, assignment_date) FROM '$$PATH$$/2440.dat';

--
-- Name: standard_has_notified_body_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('standard_has_notified_body_id_seq', 1220, true);


--
-- Name: standard_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('standard_id_seq', 464, true);


--
-- Data for Name: standard_is_in_standard_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY standard_is_in_standard_group (standard_id, standard_group_id) FROM stdin;
\.
COPY standard_is_in_standard_group (standard_id, standard_group_id) FROM '$$PATH$$/2442.dat';

--
-- Data for Name: user_has_authority; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY user_has_authority (user_id, authority_id) FROM stdin;
\.
COPY user_has_authority (user_id, authority_id) FROM '$$PATH$$/2443.dat';

--
-- Data for Name: user_has_online_publication; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY user_has_online_publication (id, changed, created, validity, portal_product_id, user_id) FROM stdin;
\.
COPY user_has_online_publication (id, changed, created, validity, portal_product_id, user_id) FROM '$$PATH$$/2462.dat';

--
-- Name: user_has_online_publication_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('user_has_online_publication_seq', 223, true);


--
-- Data for Name: user_info; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY user_info (city, company_name, dic, ico, phone, street, zip, user_id, sgp_sync_ok, portal_country) FROM stdin;
\.
COPY user_info (city, company_name, dic, ico, phone, street, zip, user_id, sgp_sync_ok, portal_country) FROM '$$PATH$$/2454.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY users (id, changed, code, created, enabled, email, first_name, last_name, password, id_user_changed_by, id_user_created_by, change_pass_req_date, change_pass_req_token, registration_validity, sgp_password) FROM stdin;
\.
COPY users (id, changed, code, created, enabled, email, first_name, last_name, password, id_user_changed_by, id_user_created_by, change_pass_req_date, change_pass_req_token, registration_validity, sgp_password) FROM '$$PATH$$/2444.dat';

--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('users_id_seq', 41, true);


--
-- Data for Name: users_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY users_log (id, ip_address, login_date, login_success, logout_date, session_id, user_name, id_user) FROM stdin;
\.
COPY users_log (id, ip_address, login_date, login_success, logout_date, session_id, user_name, id_user) FROM '$$PATH$$/2446.dat';

--
-- Name: users_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('users_log_id_seq', 1052, true);


--
-- Data for Name: webpage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY webpage (id, changed, code, created, enabled, avatar, is_locked, webpage_order, published_since, redirect_url, webpage_type, id_user_changed_by, id_user_created_by, parent_id, redirect_webpage_id, is_locked_code, is_locked_remove, webpage_modlue, show_thumb, only_for_registraged, full_page_width, hit) FROM stdin;
\.
COPY webpage (id, changed, code, created, enabled, avatar, is_locked, webpage_order, published_since, redirect_url, webpage_type, id_user_changed_by, id_user_created_by, parent_id, redirect_webpage_id, is_locked_code, is_locked_remove, webpage_modlue, show_thumb, only_for_registraged, full_page_width, hit) FROM '$$PATH$$/2452.dat';

--
-- Data for Name: webpage_content; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY webpage_content (webpage_id, content, description, name, title, url, localized_key) FROM stdin;
\.
COPY webpage_content (webpage_id, content, description, name, title, url, localized_key) FROM '$$PATH$$/2453.dat';

--
-- Name: webpage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('webpage_id_seq', 325, true);


--
-- Name: address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY address
    ADD CONSTRAINT address_pkey PRIMARY KEY (id);


--
-- Name: article_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY article
    ADD CONSTRAINT article_pkey PRIMARY KEY (id);


--
-- Name: assessment_system_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY assessment_system
    ADD CONSTRAINT assessment_system_pkey PRIMARY KEY (id);


--
-- Name: authority_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY authority
    ADD CONSTRAINT authority_pkey PRIMARY KEY (id);


--
-- Name: basic_requirement_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY basic_requirement
    ADD CONSTRAINT basic_requirement_pkey PRIMARY KEY (id);


--
-- Name: basic_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY basic_settings
    ADD CONSTRAINT basic_settings_pkey PRIMARY KEY (id);


--
-- Name: commission_decision_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY commission_decision
    ADD CONSTRAINT commission_decision_pkey PRIMARY KEY (id);


--
-- Name: country_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY country
    ADD CONSTRAINT country_pkey PRIMARY KEY (id);


--
-- Name: csn_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY csn_category
    ADD CONSTRAINT csn_category_pkey PRIMARY KEY (id);


--
-- Name: csn_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY csn
    ADD CONSTRAINT csn_pkey PRIMARY KEY (id);


--
-- Name: csn_terminology_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY csn_terminology_log
    ADD CONSTRAINT csn_terminology_log_pkey PRIMARY KEY (id);


--
-- Name: csn_terminology_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY csn_terminology
    ADD CONSTRAINT csn_terminology_pkey PRIMARY KEY (id);


--
-- Name: email_template_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY email_template
    ADD CONSTRAINT email_template_pkey PRIMARY KEY (id);


--
-- Name: exception_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exception_log
    ADD CONSTRAINT exception_log_pkey PRIMARY KEY (id);


--
-- Name: mandate_has_changes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY mandate_has_changes
    ADD CONSTRAINT mandate_has_changes_pkey PRIMARY KEY (mandate_id, mandate_change_id);


--
-- Name: mandate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY mandate
    ADD CONSTRAINT mandate_pkey PRIMARY KEY (id);


--
-- Name: notified_body_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY notified_body
    ADD CONSTRAINT notified_body_pkey PRIMARY KEY (id);


--
-- Name: portal_order_has_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY portal_order_has_items
    ADD CONSTRAINT portal_order_has_items_pkey PRIMARY KEY (id);


--
-- Name: portal_order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY portal_order
    ADD CONSTRAINT portal_order_pkey PRIMARY KEY (id);


--
-- Name: portal_product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY portal_product
    ADD CONSTRAINT portal_product_pkey PRIMARY KEY (id);


--
-- Name: report_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY report
    ADD CONSTRAINT report_pkey PRIMARY KEY (id);


--
-- Name: requirement_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY requirement
    ADD CONSTRAINT requirement_pkey PRIMARY KEY (id);


--
-- Name: standard_change_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY standard_change
    ADD CONSTRAINT standard_change_pkey PRIMARY KEY (id);


--
-- Name: standard_csn_has_change_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY standard_csn_has_change
    ADD CONSTRAINT standard_csn_has_change_pkey PRIMARY KEY (id);


--
-- Name: standard_csn_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY standard_csn
    ADD CONSTRAINT standard_csn_pkey PRIMARY KEY (id);


--
-- Name: standard_group_has_mandate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY standard_group_has_mandate
    ADD CONSTRAINT standard_group_has_mandate_pkey PRIMARY KEY (standard_group_id, mandates_id);


--
-- Name: standard_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY standard_group
    ADD CONSTRAINT standard_group_pkey PRIMARY KEY (id);


--
-- Name: standard_has_assessment_system_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY standard_has_assessment_system
    ADD CONSTRAINT standard_has_assessment_system_pkey PRIMARY KEY (standard_id, notified_body_id);


--
-- Name: standard_has_csn_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY standard_has_csn
    ADD CONSTRAINT standard_has_csn_pkey PRIMARY KEY (standard_id, standard_csn_id);


--
-- Name: standard_has_notified_body_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY standard_has_notified_body
    ADD CONSTRAINT standard_has_notified_body_pkey PRIMARY KEY (standard_id, notified_body_id);


--
-- Name: standard_is_in_standard_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY standard_is_in_standard_group
    ADD CONSTRAINT standard_is_in_standard_group_pkey PRIMARY KEY (standard_id, standard_group_id);


--
-- Name: standard_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY standard
    ADD CONSTRAINT standard_pkey PRIMARY KEY (id);


--
-- Name: uk_37dlhwuq5okdrf1101psyxtpw; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY standard_group_has_mandate
    ADD CONSTRAINT uk_37dlhwuq5okdrf1101psyxtpw UNIQUE (mandates_id);


--
-- Name: user_has_authority_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY user_has_authority
    ADD CONSTRAINT user_has_authority_pkey PRIMARY KEY (user_id, authority_id);


--
-- Name: user_has_online_publication_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY user_has_online_publication
    ADD CONSTRAINT user_has_online_publication_pkey PRIMARY KEY (id);


--
-- Name: user_info_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY user_info
    ADD CONSTRAINT user_info_pkey PRIMARY KEY (user_id);


--
-- Name: users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY users_log
    ADD CONSTRAINT users_log_pkey PRIMARY KEY (id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webpage_content_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY webpage_content
    ADD CONSTRAINT webpage_content_pkey PRIMARY KEY (webpage_id, localized_key);


--
-- Name: webpage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY webpage
    ADD CONSTRAINT webpage_pkey PRIMARY KEY (id);


--
-- Name: fk181fe3f21b2ce; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY csn
    ADD CONSTRAINT fk181fe3f21b2ce FOREIGN KEY (id_user_changed_by) REFERENCES users(id);


--
-- Name: fk181fe648007c6; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY csn
    ADD CONSTRAINT fk181fe648007c6 FOREIGN KEY (csn_category_id) REFERENCES csn_category(id);


--
-- Name: fk181fefd0ba1a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY csn
    ADD CONSTRAINT fk181fefd0ba1a FOREIGN KEY (id_user_created_by) REFERENCES users(id);


--
-- Name: fk1c1b55f23f21b2ce; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY csn_terminology
    ADD CONSTRAINT fk1c1b55f23f21b2ce FOREIGN KEY (id_user_changed_by) REFERENCES users(id);


--
-- Name: fk1c1b55f248fdeb69; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY csn_terminology
    ADD CONSTRAINT fk1c1b55f248fdeb69 FOREIGN KEY (csn_id) REFERENCES csn(id);


--
-- Name: fk1c1b55f2fd0ba1a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY csn_terminology
    ADD CONSTRAINT fk1c1b55f2fd0ba1a FOREIGN KEY (id_user_created_by) REFERENCES users(id);


--
-- Name: fk3075ed143f21b2ce; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY basic_settings
    ADD CONSTRAINT fk3075ed143f21b2ce FOREIGN KEY (id_user_changed_by) REFERENCES users(id);


--
-- Name: fk3075ed14fd0ba1a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY basic_settings
    ADD CONSTRAINT fk3075ed14fd0ba1a FOREIGN KEY (id_user_created_by) REFERENCES users(id);


--
-- Name: fk391757963f21b2ce; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY country
    ADD CONSTRAINT fk391757963f21b2ce FOREIGN KEY (id_user_changed_by) REFERENCES users(id);


--
-- Name: fk39175796fd0ba1a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY country
    ADD CONSTRAINT fk39175796fd0ba1a FOREIGN KEY (id_user_created_by) REFERENCES users(id);


--
-- Name: fk51e7df7748fdeb69; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY csn_terminology_log
    ADD CONSTRAINT fk51e7df7748fdeb69 FOREIGN KEY (csn_id) REFERENCES csn(id);


--
-- Name: fk51e7df778e81854b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY csn_terminology_log
    ADD CONSTRAINT fk51e7df778e81854b FOREIGN KEY (user_id) REFERENCES users(id);


--
-- Name: fk57f407433f21b2ce; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY authority
    ADD CONSTRAINT fk57f407433f21b2ce FOREIGN KEY (id_user_changed_by) REFERENCES users(id);


--
-- Name: fk57f40743fd0ba1a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY authority
    ADD CONSTRAINT fk57f40743fd0ba1a FOREIGN KEY (id_user_created_by) REFERENCES users(id);


--
-- Name: fk6a68e083f21b2ce; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users
    ADD CONSTRAINT fk6a68e083f21b2ce FOREIGN KEY (id_user_changed_by) REFERENCES users(id);


--
-- Name: fk6a68e08fd0ba1a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users
    ADD CONSTRAINT fk6a68e08fd0ba1a FOREIGN KEY (id_user_created_by) REFERENCES users(id);


--
-- Name: fk881539b23f21b2ce; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY basic_requirement
    ADD CONSTRAINT fk881539b23f21b2ce FOREIGN KEY (id_user_changed_by) REFERENCES users(id);


--
-- Name: fk881539b2fd0ba1a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY basic_requirement
    ADD CONSTRAINT fk881539b2fd0ba1a FOREIGN KEY (id_user_created_by) REFERENCES users(id);


--
-- Name: fk98065a6a8e81854b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY user_has_authority
    ADD CONSTRAINT fk98065a6a8e81854b FOREIGN KEY (user_id) REFERENCES users(id);


--
-- Name: fk98065a6a96a55a09; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY user_has_authority
    ADD CONSTRAINT fk98065a6a96a55a09 FOREIGN KEY (authority_id) REFERENCES authority(id);


--
-- Name: fk_1c21j4t3nn9ltf0e01bu5sjbc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY user_has_online_publication
    ADD CONSTRAINT fk_1c21j4t3nn9ltf0e01bu5sjbc FOREIGN KEY (portal_product_id) REFERENCES portal_product(id);


--
-- Name: fk_2irlnhxd5ivn3hl259y5e11ml; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY standard
    ADD CONSTRAINT fk_2irlnhxd5ivn3hl259y5e11ml FOREIGN KEY (replaced_standard_id) REFERENCES standard(id);


--
-- Name: fk_37dlhwuq5okdrf1101psyxtpw; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY standard_group_has_mandate
    ADD CONSTRAINT fk_37dlhwuq5okdrf1101psyxtpw FOREIGN KEY (mandates_id) REFERENCES mandate(id);


--
-- Name: fk_3lvtpd1f6nocxyw8c225brv0t; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY standard_has_notified_body
    ADD CONSTRAINT fk_3lvtpd1f6nocxyw8c225brv0t FOREIGN KEY (standard_id) REFERENCES standard(id);


--
-- Name: fk_3qxxgge6ui0khvkrq8cnva8uw; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY standard_csn_has_change
    ADD CONSTRAINT fk_3qxxgge6ui0khvkrq8cnva8uw FOREIGN KEY (standard_id) REFERENCES standard_csn(id);


--
-- Name: fk_3r0y4dttn783u41ogony8fkoy; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY standard_csn_has_change
    ADD CONSTRAINT fk_3r0y4dttn783u41ogony8fkoy FOREIGN KEY (id_user_changed_by) REFERENCES users(id);


--
-- Name: fk_3rlmxg1qhxy4aqitocnwr15ts; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY standard_is_in_standard_group
    ADD CONSTRAINT fk_3rlmxg1qhxy4aqitocnwr15ts FOREIGN KEY (standard_id) REFERENCES standard(id);


--
-- Name: fk_49udthtt1cijmruv7sslabua6; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY standard_change
    ADD CONSTRAINT fk_49udthtt1cijmruv7sslabua6 FOREIGN KEY (standard_id) REFERENCES standard(id);


--
-- Name: fk_4w9x2vs83e5fwykw0vhow8frc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY portal_product
    ADD CONSTRAINT fk_4w9x2vs83e5fwykw0vhow8frc FOREIGN KEY (id_user_changed_by) REFERENCES users(id);


--
-- Name: fk_54cys1kariva684yhcnda0m8s; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY requirement
    ADD CONSTRAINT fk_54cys1kariva684yhcnda0m8s FOREIGN KEY (country_id) REFERENCES country(id);


--
-- Name: fk_5ycc2x7u9euxpes8hvqksygp0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users_log
    ADD CONSTRAINT fk_5ycc2x7u9euxpes8hvqksygp0 FOREIGN KEY (id_user) REFERENCES users(id);


--
-- Name: fk_6k4i2jdt64328hsnqi0agy4n; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY webpage_content
    ADD CONSTRAINT fk_6k4i2jdt64328hsnqi0agy4n FOREIGN KEY (webpage_id) REFERENCES webpage(id);


--
-- Name: fk_6ph7ep7r2xgpq9nrah0fogtet; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY portal_order_has_items
    ADD CONSTRAINT fk_6ph7ep7r2xgpq9nrah0fogtet FOREIGN KEY (portal_order_id) REFERENCES portal_order(id);


--
-- Name: fk_6u1pm8t40m988rrxwhyc1juki; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY standard_csn
    ADD CONSTRAINT fk_6u1pm8t40m988rrxwhyc1juki FOREIGN KEY (id_user_changed_by) REFERENCES users(id);


--
-- Name: fk_75otiiiitgh92frfkp184k9lt; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY standard_group
    ADD CONSTRAINT fk_75otiiiitgh92frfkp184k9lt FOREIGN KEY (commission_decision_id) REFERENCES commission_decision(id);


--
-- Name: fk_7myi2776jwujobisbhjyywjkj; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY standard_change
    ADD CONSTRAINT fk_7myi2776jwujobisbhjyywjkj FOREIGN KEY (id_user_created_by) REFERENCES users(id);


--
-- Name: fk_8rb6uy7cjjq6rg8kb0a6f9q9c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY portal_order
    ADD CONSTRAINT fk_8rb6uy7cjjq6rg8kb0a6f9q9c FOREIGN KEY (id_user_changed_by) REFERENCES users(id);


--
-- Name: fk_9bdjqgopmkq9cl70fbwr39a6j; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY email_template
    ADD CONSTRAINT fk_9bdjqgopmkq9cl70fbwr39a6j FOREIGN KEY (id_user_created_by) REFERENCES users(id);


--
-- Name: fk_9tu3mlf5j9oecnkpypw0eyyxg; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY user_has_online_publication
    ADD CONSTRAINT fk_9tu3mlf5j9oecnkpypw0eyyxg FOREIGN KEY (user_id) REFERENCES users(id);


--
-- Name: fk_ahl4iuqu9ahlrl4f06a2d65b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY notified_body
    ADD CONSTRAINT fk_ahl4iuqu9ahlrl4f06a2d65b FOREIGN KEY (address_id) REFERENCES address(id);


--
-- Name: fk_b1ohit61ufo3b2oq4btbvh35x; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY report
    ADD CONSTRAINT fk_b1ohit61ufo3b2oq4btbvh35x FOREIGN KEY (id_user_changed_by) REFERENCES users(id);


--
-- Name: fk_ckjftfsclfj5h45umpm61gul1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY webpage
    ADD CONSTRAINT fk_ckjftfsclfj5h45umpm61gul1 FOREIGN KEY (parent_id) REFERENCES webpage(id);


--
-- Name: fk_cpid370p4nb8maq79x0xlcl1r; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY standard_group
    ADD CONSTRAINT fk_cpid370p4nb8maq79x0xlcl1r FOREIGN KEY (id_user_created_by) REFERENCES users(id);


--
-- Name: fk_cstv0dod9eyftq6sy61if16h0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY commission_decision
    ADD CONSTRAINT fk_cstv0dod9eyftq6sy61if16h0 FOREIGN KEY (id_user_changed_by) REFERENCES users(id);


--
-- Name: fk_dbisqq23p4gj38mlscmsfuhj3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY portal_product
    ADD CONSTRAINT fk_dbisqq23p4gj38mlscmsfuhj3 FOREIGN KEY (id_user_created_by) REFERENCES users(id);


--
-- Name: fk_eaqdsc67gam54qoi3m9oaevcq; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY standard_has_notified_body
    ADD CONSTRAINT fk_eaqdsc67gam54qoi3m9oaevcq FOREIGN KEY (notified_body_id) REFERENCES notified_body(id);


--
-- Name: fk_ef80oxh2fpae67i8986k5pcq6; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY standard_has_csn
    ADD CONSTRAINT fk_ef80oxh2fpae67i8986k5pcq6 FOREIGN KEY (standard_csn_id) REFERENCES standard_csn(id);


--
-- Name: fk_etyark37h3bq05h9d3gryr672; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY notified_body
    ADD CONSTRAINT fk_etyark37h3bq05h9d3gryr672 FOREIGN KEY (id_user_changed_by) REFERENCES users(id);


--
-- Name: fk_f8eis4obuupn0wgi3pbh1qsth; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY email_template
    ADD CONSTRAINT fk_f8eis4obuupn0wgi3pbh1qsth FOREIGN KEY (id_user_changed_by) REFERENCES users(id);


--
-- Name: fk_fddggr2edrbye5lk53s29vj5q; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY webpage
    ADD CONSTRAINT fk_fddggr2edrbye5lk53s29vj5q FOREIGN KEY (id_user_changed_by) REFERENCES users(id);


--
-- Name: fk_fdjbg6kaey93ccbpr7x5rhbb8; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY standard
    ADD CONSTRAINT fk_fdjbg6kaey93ccbpr7x5rhbb8 FOREIGN KEY (id_user_created_by) REFERENCES users(id);


--
-- Name: fk_gkgcaiwfkpti588ful21ol8ik; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY standard_group
    ADD CONSTRAINT fk_gkgcaiwfkpti588ful21ol8ik FOREIGN KEY (id_user_changed_by) REFERENCES users(id);


--
-- Name: fk_hc5p5va1pmpwtrnp0t2j01l94; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY notified_body
    ADD CONSTRAINT fk_hc5p5va1pmpwtrnp0t2j01l94 FOREIGN KEY (id_user_created_by) REFERENCES users(id);


--
-- Name: fk_hixwjgx0ynne0cq4tqvoawoda; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY user_info
    ADD CONSTRAINT fk_hixwjgx0ynne0cq4tqvoawoda FOREIGN KEY (user_id) REFERENCES users(id);


--
-- Name: fk_i0n07f03qrkhtilyl3vbrdodi; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY standard_csn_has_change
    ADD CONSTRAINT fk_i0n07f03qrkhtilyl3vbrdodi FOREIGN KEY (id_user_created_by) REFERENCES users(id);


--
-- Name: fk_i0n1qlljmtn83c2wqed3dcx8e; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY notified_body
    ADD CONSTRAINT fk_i0n1qlljmtn83c2wqed3dcx8e FOREIGN KEY (country_id) REFERENCES country(id);


--
-- Name: fk_ibve81dw50a1p92mjh136l9ex; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mandate_has_changes
    ADD CONSTRAINT fk_ibve81dw50a1p92mjh136l9ex FOREIGN KEY (mandate_id) REFERENCES mandate(id);


--
-- Name: fk_iqa31ers1cyku9wkgnrnhdmvu; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY commission_decision
    ADD CONSTRAINT fk_iqa31ers1cyku9wkgnrnhdmvu FOREIGN KEY (id_user_created_by) REFERENCES users(id);


--
-- Name: fk_j5p7na06bgelejw91af8x1x35; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY portal_order
    ADD CONSTRAINT fk_j5p7na06bgelejw91af8x1x35 FOREIGN KEY (id_user_created_by) REFERENCES users(id);


--
-- Name: fk_j9fsjxwm48w1m9moat6vbe1xj; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY standard
    ADD CONSTRAINT fk_j9fsjxwm48w1m9moat6vbe1xj FOREIGN KEY (id_user_changed_by) REFERENCES users(id);


--
-- Name: fk_kvu7dloejqvth7ne318h31huc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY requirement
    ADD CONSTRAINT fk_kvu7dloejqvth7ne318h31huc FOREIGN KEY (standard_id) REFERENCES standard(id);


--
-- Name: fk_lnu0tig6pmisdb68pogtan03l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY standard_change
    ADD CONSTRAINT fk_lnu0tig6pmisdb68pogtan03l FOREIGN KEY (id_user_changed_by) REFERENCES users(id);


--
-- Name: fk_m515qyvdoleoeriawem2vgibb; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mandate_has_changes
    ADD CONSTRAINT fk_m515qyvdoleoeriawem2vgibb FOREIGN KEY (mandate_change_id) REFERENCES mandate(id);


--
-- Name: fk_mpap9pjx2xb9qbwuh0scnsvw2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY report
    ADD CONSTRAINT fk_mpap9pjx2xb9qbwuh0scnsvw2 FOREIGN KEY (id_user_created_by) REFERENCES users(id);


--
-- Name: fk_mx2fl8ffv40qwaq5nvcmw1y6b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY requirement
    ADD CONSTRAINT fk_mx2fl8ffv40qwaq5nvcmw1y6b FOREIGN KEY (id_user_changed_by) REFERENCES users(id);


--
-- Name: fk_ndimff0ixagbxhc5l1lvi2ub1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY standard_csn
    ADD CONSTRAINT fk_ndimff0ixagbxhc5l1lvi2ub1 FOREIGN KEY (replaced_standard_csn_id) REFERENCES standard_csn(id);


--
-- Name: fk_onmnajpvotgcd895vg0tcss2a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY standard_group_has_mandate
    ADD CONSTRAINT fk_onmnajpvotgcd895vg0tcss2a FOREIGN KEY (standard_group_id) REFERENCES standard_group(id);


--
-- Name: fk_oqmweaqmlp2qdd6f3vquwp0v5; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exception_log
    ADD CONSTRAINT fk_oqmweaqmlp2qdd6f3vquwp0v5 FOREIGN KEY (user_id) REFERENCES users(id);


--
-- Name: fk_p2yix7iis19l0uyg00uut01xm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY standard_is_in_standard_group
    ADD CONSTRAINT fk_p2yix7iis19l0uyg00uut01xm FOREIGN KEY (standard_group_id) REFERENCES standard_group(id);


--
-- Name: fk_pa9lhieqojw7axvckoyjfuarv; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY standard_has_csn
    ADD CONSTRAINT fk_pa9lhieqojw7axvckoyjfuarv FOREIGN KEY (standard_id) REFERENCES standard(id);


--
-- Name: fk_ph5bf3u42jpk7ygfxp3rp7fdc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY requirement
    ADD CONSTRAINT fk_ph5bf3u42jpk7ygfxp3rp7fdc FOREIGN KEY (id_user_created_by) REFERENCES users(id);


--
-- Name: fk_pylea48c2myf1l9sln72m7k70; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY portal_order_has_items
    ADD CONSTRAINT fk_pylea48c2myf1l9sln72m7k70 FOREIGN KEY (portal_product_id) REFERENCES portal_product(id);


--
-- Name: fk_q7io6vgavcyoodhv5dxyne1mu; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY webpage
    ADD CONSTRAINT fk_q7io6vgavcyoodhv5dxyne1mu FOREIGN KEY (redirect_webpage_id) REFERENCES webpage(id);


--
-- Name: fk_qk3igydwnanmd1b0nxfr6l9tv; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY standard_csn
    ADD CONSTRAINT fk_qk3igydwnanmd1b0nxfr6l9tv FOREIGN KEY (id_user_created_by) REFERENCES users(id);


--
-- Name: fk_r2rrkux4qw05h1hdv6aweh5r3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mandate
    ADD CONSTRAINT fk_r2rrkux4qw05h1hdv6aweh5r3 FOREIGN KEY (id_user_changed_by) REFERENCES users(id);


--
-- Name: fk_rd9bbp76ioumgfkaeq6c0anyd; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY webpage
    ADD CONSTRAINT fk_rd9bbp76ioumgfkaeq6c0anyd FOREIGN KEY (id_user_created_by) REFERENCES users(id);


--
-- Name: fk_rh7af47sextrnjycqdwhrc5bf; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY standard_has_assessment_system
    ADD CONSTRAINT fk_rh7af47sextrnjycqdwhrc5bf FOREIGN KEY (standard_id) REFERENCES standard(id);


--
-- Name: fk_rk252bmpbvclb0lmvfk07ne38; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY standard_has_assessment_system
    ADD CONSTRAINT fk_rk252bmpbvclb0lmvfk07ne38 FOREIGN KEY (notified_body_id) REFERENCES assessment_system(id);


--
-- Name: fk_sb5ifbeusyqn97v3e11m8fcvw; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mandate
    ADD CONSTRAINT fk_sb5ifbeusyqn97v3e11m8fcvw FOREIGN KEY (id_user_created_by) REFERENCES users(id);


--
-- Name: fk_tl09nadh1dd4q0qn014e7yo16; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY portal_order
    ADD CONSTRAINT fk_tl09nadh1dd4q0qn014e7yo16 FOREIGN KEY (user_id) REFERENCES users(id);


--
-- Name: fkbb979bf43f21b2ce; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY address
    ADD CONSTRAINT fkbb979bf43f21b2ce FOREIGN KEY (id_user_changed_by) REFERENCES users(id);


--
-- Name: fkbb979bf4fd0ba1a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY address
    ADD CONSTRAINT fkbb979bf4fd0ba1a FOREIGN KEY (id_user_created_by) REFERENCES users(id);


--
-- Name: fkd458ccf63f21b2ce; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY article
    ADD CONSTRAINT fkd458ccf63f21b2ce FOREIGN KEY (id_user_changed_by) REFERENCES users(id);


--
-- Name: fkd458ccf6fd0ba1a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY article
    ADD CONSTRAINT fkd458ccf6fd0ba1a FOREIGN KEY (id_user_created_by) REFERENCES users(id);


--
-- Name: fkdc65ca1f3f21b2ce; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY csn_category
    ADD CONSTRAINT fkdc65ca1f3f21b2ce FOREIGN KEY (id_user_changed_by) REFERENCES users(id);


--
-- Name: fkdc65ca1ff689395b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY csn_category
    ADD CONSTRAINT fkdc65ca1ff689395b FOREIGN KEY (parent_id) REFERENCES csn_category(id);


--
-- Name: fkdc65ca1ffd0ba1a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY csn_category
    ADD CONSTRAINT fkdc65ca1ffd0ba1a FOREIGN KEY (id_user_created_by) REFERENCES users(id);


--
-- Name: fkf2f47a4c3f21b2ce; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY assessment_system
    ADD CONSTRAINT fkf2f47a4c3f21b2ce FOREIGN KEY (id_user_changed_by) REFERENCES users(id);


--
-- Name: fkf2f47a4cfd0ba1a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY assessment_system
    ADD CONSTRAINT fkf2f47a4cfd0ba1a FOREIGN KEY (id_user_created_by) REFERENCES users(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: itcuser
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM itcuser;
GRANT ALL ON SCHEMA public TO itcuser;


--
-- PostgreSQL database dump complete
--

